import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../helpers';


@Component({
selector: "app-inner2",
templateUrl: "./inner2.component.html",
encapsulation: ViewEncapsulation.None,
})
export class Inner2Component implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}