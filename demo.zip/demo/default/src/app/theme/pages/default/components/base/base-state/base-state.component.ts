import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-base-state",
templateUrl: "./base-state.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseStateComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}