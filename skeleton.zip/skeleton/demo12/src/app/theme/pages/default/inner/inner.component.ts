import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../helpers';


@Component({
selector: "app-inner",
templateUrl: "./inner.component.html",
encapsulation: ViewEncapsulation.None,
})
export class InnerComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}