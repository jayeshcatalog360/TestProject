import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-timeline-timeline-1",
templateUrl: "./timeline-timeline-1.component.html",
encapsulation: ViewEncapsulation.None,
})
export class TimelineTimeline1Component implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}