import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-base-typography",
templateUrl: "./base-typography.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseTypographyComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}