import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../helpers';


@Component({
selector: "app-actions",
templateUrl: "./actions.component.html",
encapsulation: ViewEncapsulation.None,
})
export class ActionsComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}