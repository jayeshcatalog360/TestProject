import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
selector: "app-tabs-line",
templateUrl: "./tabs-line.component.html",
encapsulation: ViewEncapsulation.None,
})
export class TabsLineComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}