import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-base-lists",
templateUrl: "./base-lists.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseListsComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}