import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-portlets-advanced",
templateUrl: "./portlets-advanced.component.html",
encapsulation: ViewEncapsulation.None,
})
export class PortletsAdvancedComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}