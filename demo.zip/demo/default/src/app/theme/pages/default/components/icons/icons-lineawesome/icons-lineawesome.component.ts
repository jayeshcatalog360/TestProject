import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-icons-lineawesome",
templateUrl: "./icons-lineawesome.component.html",
encapsulation: ViewEncapsulation.None,
})
export class IconsLineawesomeComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}