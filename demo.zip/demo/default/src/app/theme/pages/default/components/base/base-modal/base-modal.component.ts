import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-base-modal",
templateUrl: "./base-modal.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseModalComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}