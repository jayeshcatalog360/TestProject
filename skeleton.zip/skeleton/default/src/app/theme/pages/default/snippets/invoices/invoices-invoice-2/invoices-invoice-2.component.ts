import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-invoices-invoice-2",
templateUrl: "./invoices-invoice-2.component.html",
encapsulation: ViewEncapsulation.None,
})
export class InvoicesInvoice2Component implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}