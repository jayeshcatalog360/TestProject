import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
selector: "app-layouts-multi-column-forms",
templateUrl: "./layouts-multi-column-forms.component.html",
encapsulation: ViewEncapsulation.None,
})
export class LayoutsMultiColumnFormsComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}