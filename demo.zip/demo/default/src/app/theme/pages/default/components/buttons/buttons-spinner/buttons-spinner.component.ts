import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-buttons-spinner",
templateUrl: "./buttons-spinner.component.html",
encapsulation: ViewEncapsulation.None,
})
export class ButtonsSpinnerComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}