import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-portlets-base",
templateUrl: "./portlets-base.component.html",
encapsulation: ViewEncapsulation.None,
})
export class PortletsBaseComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}