import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-base-navs",
templateUrl: "./base-navs.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseNavsComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}