import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-portlets-creative",
templateUrl: "./portlets-creative.component.html",
encapsulation: ViewEncapsulation.None,
})
export class PortletsCreativeComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}